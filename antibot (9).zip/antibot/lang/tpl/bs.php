<?php
// This translation has not been verified by a native speaker.
// Bosnian
// Last update: 2020.05.18
$pt['en'] = 'bs';
$pt['Click to continue'] = 'Kliknite za nastavak';
$pt['Just a moment...'] = 'Čekajte!'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Uključite JavaScript i ponovno učitajte stranicu.';
$pt['Checking your browser before accessing the website.'] = 'Provjera preglednika prije pristupa web lokaciji.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ovaj postupak je automatski. Vaš preglednik će uskoro preusmjeriti na traženi sadržaj.';
$pt['Please wait a few seconds.'] = 'Pričekajte nekoliko sekundi.';
$pt['Loading page, please wait...'] = 'Učitavanje stranice, pričekajte...';
