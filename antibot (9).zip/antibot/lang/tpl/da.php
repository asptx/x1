<?php
// This translation has not been verified by a native speaker.
// Danish
// Last update: 2020.05.18
$pt['en'] = 'da';
$pt['Click to continue'] = 'Klik for at fortsætte';
$pt['Just a moment...'] = 'Vente.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Tænd venligst JavaScript, og indlæs siden igen.';
$pt['Checking your browser before accessing the website.'] = 'Kontroller din browser, før du går ind på webstedet.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Denne proces er automatisk. Din browser vil omdirigere til det ønskede indhold inden for kort tid.';
$pt['Please wait a few seconds.'] = 'Vent et par sekunder.';
$pt['Loading page, please wait...'] = 'Indlæser side, vent venligst...';
