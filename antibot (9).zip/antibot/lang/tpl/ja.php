<?php
// This translation has not been verified by a native speaker.
// Japanese
// Last update: 2020.05.18
$pt['en'] = 'ja';
$pt['Click to continue'] = '続けるにはクリック';
$pt['Just a moment...'] = '待つ。'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'JavaScriptをオンにして、ページを再読み込みしてください。';
$pt['Checking your browser before accessing the website.'] = 'サイトにアクセスする前にブラウザを確認してください。';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'このプロセスは自動です。 ブラウザーは要求されたコンテンツに間もなくリダイレクトされます。';
$pt['Please wait a few seconds.'] = '数秒お待ちください';
$pt['Loading page, please wait...'] = 'ページを読み込んでいます。お待ちください...';
