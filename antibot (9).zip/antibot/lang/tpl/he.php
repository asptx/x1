<?php
// This translation has not been verified by a native speaker.
// Hebrew (Иврит)
// Last update: 2020.05.18
$pt['ltr'] = 'rtl';
$pt['en'] = 'he';
$pt['Click to continue'] = 'לחץ כדי להמשיך';
$pt['Just a moment...'] = 'חכה';
$pt['Please turn JavaScript on and reload the page.'] = 'אנא הפעל JavaScript וטען מחדש את הדף.';
$pt['Checking your browser before accessing the website.'] = 'בדוק את הדפדפן שלך לפני שאתה ניגש לאתר.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'תהליך זה הוא אוטומטי. הדפדפן שלך יפנה לתוכן המבוקש שלך תוך זמן קצר.';
$pt['Please wait a few seconds.'] = 'אנא המתן מספר שניות';
$pt['Loading page, please wait...'] = 'טוען דף, אנא המתן ...';
