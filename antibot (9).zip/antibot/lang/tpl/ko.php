<?php
// This translation has not been verified by a native speaker.
// Korean
// Last update: 2020.05.18
$pt['en'] = 'ko';
$pt['Click to continue'] = '계속하려면 클릭';
$pt['Just a moment...'] = '기다림.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'JavaScript를 켜고 페이지를 다시로드하십시오.';
$pt['Checking your browser before accessing the website.'] = '사이트에 액세스하기 전에 브라우저를 확인하십시오.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = '이 과정은 자동입니다. 브라우저가 곧 요청한 콘텐츠로 리디렉션됩니다.';
$pt['Please wait a few seconds.'] = '몇 초 기다리십시오';
$pt['Loading page, please wait...'] = '페이지로드 중입니다. 잠시만 기다려주십시오.';
