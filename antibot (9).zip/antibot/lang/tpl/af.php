<?php
// This translation has not been verified by a native speaker.
// Afrikaans
// Last update: 2020.05.18
$pt['en'] = 'af';
$pt['Click to continue'] = 'Klik om voort te gaan';
$pt['Just a moment...'] = 'Wag.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Skakel JavaScript aan en herlaai die bladsy.';
$pt['Checking your browser before accessing the website.'] = 'Kontroleer u blaaier voordat u toegang tot die webwerf verkry.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Hierdie proses is outomaties. U blaaier sal binnekort na u aangevraagde inhoud verwys.';
$pt['Please wait a few seconds.'] = 'Wag \'n paar sekondes.';
$pt['Loading page, please wait...'] = 'Laai bladsy, wag asseblief...';
