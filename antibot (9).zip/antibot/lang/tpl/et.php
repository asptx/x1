<?php
// This translation has not been verified by a native speaker.
// Estonian
// Last update: 2020.05.18
$pt['en'] = 'et';
$pt['Click to continue'] = 'Jätkamiseks klõpsake';
$pt['Just a moment...'] = 'Oota.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Lülitage JavaScript sisse ja laadige leht uuesti.';
$pt['Checking your browser before accessing the website.'] = 'Enne saidile pääsemist oma brauseri kontrollimine.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'See protsess on automaatne. Teie brauser suunab varsti teie soovitud sisu juurde.';
$pt['Please wait a few seconds.'] = 'Oodake mõni sekund.';
$pt['Loading page, please wait...'] = 'Lehte laaditakse, palun oodake...';
