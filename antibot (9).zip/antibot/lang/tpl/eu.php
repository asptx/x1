<?php
// This translation has not been verified by a native speaker.
// Basque
// Last update: 2020.05.18
$pt['en'] = 'eu';
$pt['Click to continue'] = 'Jarraitzeko klik egin';
$pt['Just a moment...'] = 'Itxaron.'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Mesedez, aktibatu JavaScript eta berriro kargatu orria.';
$pt['Checking your browser before accessing the website.'] = 'Gunean sartu aurretik arakatzailea egiaztatu.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Prozesu hau automatikoa da. Zure nabigatzaileak laster eskatuko du eskatutako edukira.';
$pt['Please wait a few seconds.'] = 'Mesedez, itxaron segundo batzuk.';
$pt['Loading page, please wait...'] = 'Orrialdea kargatzen, itxaron...';
