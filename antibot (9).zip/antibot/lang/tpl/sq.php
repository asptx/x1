<?php
// This translation has not been verified by a native speaker.
// Albanian
// Last update: 2020.05.18
$pt['en'] = 'sq';
$pt['Click to continue'] = 'Klikoni për të vazhduar';
$pt['Just a moment...'] = 'Prisni...';
$pt['Please turn JavaScript on and reload the page.'] = 'Ju lutemi aktivizoni JavaScript dhe ringarkoni faqen.';
$pt['Checking your browser before accessing the website.'] = 'Kontrollimi i shfletuesit tuaj përpara se të hyni në sit.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Ky proces është automatik. Shfletuesi juaj do të ridrejtojë së shpejti në përmbajtjen tuaj të kërkuar.';
$pt['Please wait a few seconds.'] = 'Ju lutemi prisni disa sekonda.';
$pt['Loading page, please wait...'] = 'Faqja e ngarkimit, ju lutemi prisni...';
