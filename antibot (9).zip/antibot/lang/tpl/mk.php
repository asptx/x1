<?php
// This translation has not been verified by a native speaker.
// македонски јазик
// Last update: 2020.05.18
$pt['en'] = 'mk';
$pt['Click to continue'] = 'Кликнете за да продолжите';
$pt['Just a moment...'] = 'Чекај'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'Вклучете го JavaScript и повторно вчитајте ја страницата.';
$pt['Checking your browser before accessing the website.'] = 'Проверка на прелистувачот пред да пристапите на страницата.';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'Овој процес е автоматски. Вашиот прелистувач наскоро ќе се пренасочи кон бараната содржина наскоро.';
$pt['Please wait a few seconds.'] = 'Ве молиме почекајте неколку секунди.';
$pt['Loading page, please wait...'] = 'Се вчитува страница, ве молиме почекајте...';
