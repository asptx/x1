<?php
// This translation has not been verified by a native speaker.
// Bengali
// Last update: 2020.05.18
$pt['en'] = 'bn';
$pt['Click to continue'] = 'চালিয়ে যেতে ক্লিক করুন';
$pt['Just a moment...'] = 'অপেক্ষা করুন।'; // Wait.
$pt['Please turn JavaScript on and reload the page.'] = 'দয়া করে জাভাস্ক্রিপ্ট চালু করুন এবং পৃষ্ঠাটি পুনরায় লোড করুন।';
$pt['Checking your browser before accessing the website.'] = 'সাইটে অ্যাক্সেস করার আগে আপনার ব্রাউজারটি পরীক্ষা করা হচ্ছে।';
$pt['This process is automatic. Your browser will redirect to your requested content shortly.'] = 'এই প্রক্রিয়াটি স্বয়ংক্রিয়। আপনার ব্রাউজারটি শীঘ্রই আপনার অনুরোধ করা সামগ্রীতে পুনর্নির্দেশ করবে।';
$pt['Please wait a few seconds.'] = 'কয়েক সেকেন্ড অপেক্ষা করুন.';
$pt['Loading page, please wait...'] = 'পৃষ্ঠাটি লোড হচ্ছে, দয়া করে অপেক্ষা করুন ...';
