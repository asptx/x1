<?php
/**
 * Created by PhpStorm.
 * User: lpainchaud
 * Date: 4/13/2018
 * Time: 2:16 PM
 */

$default_crak_settings = array(
    'aff_id' => 3,
    'pop' => array(
        'enabled' => false,
        'affsub' => '',
        'source' => '',
        'vertical' => 0,
    ),
    'intext' => array(
        'enabled' => false,
        'affsub' => array(''),
        'source' => array(''),
        'words' => array(''),
        'vertical' => array(0),
        'number' => array(0),
        'target' => array(true),
    ),
    'native' => array(
        'enabled' => false,
        'affsub' => '',
        'source' => '',
        'orientation' => 'straight',
        'nude' => 'non-nude',
        'tags' => array(),
        'font' => 'Arial',
        'font_size' => 12,
        'font_weight' => 'bold',
        'number_lines' => 2,
        'color' => '000000',
        'hover_color' => '000000',
        'number_thumbnails' => 4,
        'width' => 800,
        'thumbs_per_row' => 4,
        'show_thumbs' => 1,
    ),
);

$crak_native_tags = array(
    'adult paysite',
    'amateur',
    'anal',
    'asian',
    'ass',
    'bbw',
    'black',
    'blonde',
    'blowjob',
    'brunette',
    'busty',
    'cam',
    'college',
    'dating',
    'emo',
    'gaming',
    'geek',
    'gfs',
    'hardcore',
    'latina',
    'lesbian',
    'mature',
    'milf',
    'redhead',
    'small tits',
    'step family',
    'survey',
    'teen',
);

$crak_native_orientation = array(
    'straight',
    'gay',
);

$crak_native_nude = array(
    'nude',
    'both',
    'non-nude',
);